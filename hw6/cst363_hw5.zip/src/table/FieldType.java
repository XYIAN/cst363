package table;

public abstract class FieldType extends Type {

	@Override
	public abstract String toString();
}
