package table;

/**
 * A type, which can be a field type or a compound type
 * @author Glenn
 *
 */
public abstract class Type {
	
    public abstract String toString();
}
